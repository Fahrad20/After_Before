const after = document.querySelector('.after');
const before = document.querySelector('.before');
line.onmousedown = () => {
    document.body.style = 'cursor: e-resize';
    slide.onmousemove = (event) => {
        line.style.left = event.clientX - 65 + 'px';
        before.style.width = event.clientX - 65 + 'px';
    }
}
line.onmouseup = () => {
    slide.onmousemove = () => false;
    document.body.style = 'cursor: default';
};

let next = 0;
logo.onclick = () => {
    if (next == 0) {
        next++;
        before.style = 'background: url(2.png) no-repeat center/cover fixed;';
        after.style = 'background: url(1.png) no-repeat -44px 1px/cover fixed;';
        line.style.left = '50%';
    } else {
        next--;
        line.style.left = '50%';
        before.style = 'background: url(3.png) no-repeat 10px 16px/cover fixed;';
        after.style = 'background: url(4.png) no-repeat center/cover fixed;';
    }
}
